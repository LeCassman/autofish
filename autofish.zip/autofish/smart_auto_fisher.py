# Smart Auto Fisher – Restored to Fix Every 50 & 100 Fish (No Selling Logic)
import pyautogui
import time
import cv2
import numpy as np
from PIL import ImageGrab
import requests
import os
import traceback
from skimage.metrics import structural_similarity as compare_ssim

# === CONFIGURATION ===
prompt_path = 'fish_caught_prompt.png'
death_path = 'death_prompt.png'
loot_folder = 'loot_templates/'
webhook_url = "https://discord.com/api/webhooks/1372582598207082566/5sAW-qAoIgiHZpkfPUL0of3Tdz8ZxMneod36dvptOkgpK0_V6795OBl99MgFeDsYXkP3"
fix_every_x_fish = 50
fix_every_y_fish = 100
start_delay = 5
timeout = 30
confidence_threshold = 0.75
match_threshold = 0.92
inventory_region = (640, 430, 1280, 900)
fish_count_file = "fish_count.txt"

session_fish_count = 0
if os.path.exists(fish_count_file):
    with open(fish_count_file, 'r') as f:
        total_fish_count = int(f.read().strip())
else:
    total_fish_count = 0

previous_loot = {}
first_scan_done = False
reference_background = None
last_change_time = time.time()
background_static_timeout = 60
background_region = (0, 0, 300, 200)
last_inventory_image_time = time.time()
inventory_image_interval = 300  # 5 minutes
consecutive_timeouts = 0
timeout_limit = 5

def send_discord(message):
    try:
        requests.post(webhook_url, json={"content": message})
    except Exception as e:
        print(f"Discord error: {e}")

def send_inventory_image():
    try:
        screenshot = ImageGrab.grab(bbox=inventory_region)
        file_path = "inventory_snapshot.png"
        screenshot.save(file_path)

        with open(file_path, "rb") as file:
            requests.post(webhook_url, files={"file": file}, data={"content": "🖼️ Inventory Snapshot"})
    except Exception as e:
        print(f"❌ Failed to send inventory image: {e}")

def log_local_error(text):
    with open("error_log.txt", "a", encoding="utf-8") as log:
        log.write(text + "\n")

def load_image(path):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        send_discord(f"Missing required image: {path}")
        exit(1)
    return img

prompt_template = load_image(prompt_path)
death_template = load_image(death_path)

def prompt_visible():
    screenshot = ImageGrab.grab()
    gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
    res = cv2.matchTemplate(gray, prompt_template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    return max_val >= confidence_threshold

def is_dead():
    screenshot = ImageGrab.grab()
    gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
    res = cv2.matchTemplate(gray, death_template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    return max_val >= 0.75

def grab_background_region(region=background_region):
    screenshot = ImageGrab.grab(bbox=region)
    gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_BGR2GRAY)
    return gray

def is_background_static(reference, current, threshold=0.95):
    score, _ = compare_ssim(reference, current, full=True)
    return score >= threshold

def save_background_image():
    global reference_background
    screenshot = ImageGrab.grab(bbox=background_region)
    screenshot.save("reference_background.png")
    reference_background = cv2.cvtColor(np.array(screenshot), cv2.COLOR_BGR2GRAY)
    print("📸 Background captured.")

def scan_inventory_with_counts():
    if not os.path.exists(loot_folder):
        send_discord(f"Folder '{loot_folder}' not found!")
        return {}

    print("Scanning inventory...")
    screenshot = ImageGrab.grab(bbox=inventory_region)
    screenshot.save("debug_inventory.png")
    inv_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_BGR2GRAY)

    loot_counts = {}
    for filename in os.listdir(loot_folder):
        path = os.path.join(loot_folder, filename)
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue

        res = cv2.matchTemplate(inv_gray, template, cv2.TM_CCOEFF_NORMED)
        loc = np.where(res >= match_threshold)
        rectangles = []
        for pt in zip(*loc[::-1]):
            rectangles.append([pt[0], pt[1], template.shape[1], template.shape[0]])

        rectangles, _ = cv2.groupRectangles(rectangles, groupThreshold=1, eps=0.7)

        if rectangles is not None and len(rectangles) > 0:
            name = filename.replace('.png', '').replace('_', ' ').title()
            loot_counts[name] = len(rectangles)

    return loot_counts

# === MAIN LOOP ===
try:
    print(f"Starting in {start_delay} seconds...")
    send_discord("AutoFisher Bot started and ready.")
    time.sleep(start_delay)

    while True:
        if reference_background is not None:
            try:
                current_background = grab_background_region()
                if not is_background_static(reference_background, current_background):
                    if time.time() - last_change_time > background_static_timeout:
                        send_discord("@everyone Possible disconnect detected. Bot is stopping.")
                        break
                else:
                    last_change_time = time.time()
            except Exception as bg_err:
                print(f"Background check error: {bg_err}")

        if is_dead():
            send_discord("@everyone Player died! AutoFisher Bot stopped.")
            break

        start_time = time.time()
        while not prompt_visible():
            if is_dead():
                send_discord("@everyone Player died! AutoFisher Bot stopped.")
                break
            if time.time() - start_time > timeout:
                send_discord("Timeout: No fishing prompt.")
                start_time = time.time()
            time.sleep(0.2)

        pyautogui.click(button='right')
        time.sleep(1.5)

        session_fish_count += 1
        total_fish_count += 1
        with open(fish_count_file, 'w') as f:
            f.write(str(total_fish_count))

        pyautogui.press('e')
        time.sleep(1.2)

        try:
            current_loot = scan_inventory_with_counts()
        except Exception as scan_err:
            error_text = f"Inventory scan failed: {scan_err}"
            print(error_text)
            send_discord(error_text)
            log_local_error(traceback.format_exc())
            pyautogui.press('e')
            continue

        pyautogui.press('e')
        time.sleep(0.5)

        if not first_scan_done:
            previous_loot = current_loot.copy()
            first_scan_done = True
            send_discord("Inventory baseline set.")
            pyautogui.click(button='right')
            send_discord("Rod casted (baseline set).")
            time.sleep(1)
            continue

        msg = f"✅ Fish #{session_fish_count} (Total: {total_fish_count}) caught."
        print(msg)
        send_discord(msg)

        previous_loot = current_loot.copy()

        if session_fish_count % fix_every_x_fish == 0 or session_fish_count % fix_every_y_fish == 0:
            pyautogui.press('t')
            time.sleep(0.3)
            pyautogui.typewrite("/fix", interval=0.05)
            pyautogui.press('enter')
            send_discord("Rod fixed after fishing milestone.")
            time.sleep(1)

        while prompt_visible():
            time.sleep(0.2)

        pyautogui.click(button='right')
        send_discord("Rod casted again.")
        time.sleep(1)

except Exception as e:
    full_error = f"Script crashed: {str(e)}"
    print(full_error)
    send_discord(full_error)
    log_local_error(traceback.format_exc())
